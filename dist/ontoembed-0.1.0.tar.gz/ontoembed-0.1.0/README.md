# OntoEmbed

OntoEmbed is a command-line tool that converts ontologies into vector embeddings (vector stores).

## Installation

```bash
pip install ontoembed
